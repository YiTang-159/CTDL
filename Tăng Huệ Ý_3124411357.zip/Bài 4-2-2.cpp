#include <iostream>
#include <queue>
#include <string>
#include <cmath>
using namespace std;
//Hàng đợi sử dụng mảng
struct QueueInt {
    static const int MAX = 100;
    int arr[MAX];
    int front, rear;
    QueueInt() { front = rear = -1;}
    void InitQueue() { front = rear = -1;}
    bool IsEmpty() { return front == -1;}
    bool IsFull() { return (rear + 1) % MAX == front;}
    void Enqueue(int x) {
        if(IsFull()) {
            cout << "Hang doi da day\n";
            return;
        }
        if(IsEmpty()) front = 0;
        rear = (rear + 1) % MAX;
        arr[rear] = x;
    }
    int Dequeue() {
        if(IsEmpty()) return -1;
        int val = arr[front];
        if(front == rear) front = rear = -1;
        else front = (front + 1) % MAX;
        return val;
    }
    int Peek() {return IsEmpty() ? -1 : arr[front];}
    void Clear() {front = rear = -1;}
};
//Hàng đợi bằng danh sách liên kết
struct LinkedQueueInt {
    struct Node {
        int data;
        Node* next;
    };
    Node* front, * rear;
    LinkedQueueInt() {front = rear = nullptr;}
    void InitQueue() {front = rear = nullptr;}
    bool IsEmpty() {return front == nullptr;}
    void Enqueue(int x) {
        Node* newNode = new Node{x, nullptr};
        if(IsEmpty()) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            rear = newNode;
        }
    }
    int Dequeue() {
        if(IsEmpty()) return -1;
        int val = front->data;
        Node* temp = front;
        front = front->next;
        if(front == nullptr) rear = nullptr;
        delete temp;
        return val;
    }
    int Peek() {return IsEmpty() ? -1 : front->data;}
    void Clear() {while(!IsEmpty()) Dequeue();}
};
//Ứng dụng hàng đợi để xếp lịch cặp múa nam/nữ
void XepLichMua() {
    queue<string> nam, nu;
    int nNam, nNu;
    cout<<"Nhap so nguoi nam: ";
    cin>>nNam;
    cin.ignore();
    cout<<"Nhap danh sach nguoi nam:\n";
    for(int i = 0; i < nNam; i++) {
        string ten;
        getline(cin, ten);
        nam.push(ten);
    }
    cout<<"Nhap so nguoi nu: ";
    cin>>nNu;
    cin.ignore();
    cout<<"Nhap danh sach nguoi nu:\n";
    for(int i = 0; i < nNu; i++) {
        string ten;
        getline(cin, ten);
        nu.push(ten);
    }
    cout<<"\nDanh sach xep cap:\n";
    while(!nam.empty() && !nu.empty()) {
        cout<<"Cap: "<<nam.front()<<" - "<<nu.front()<<endl;
        nam.pop();
        nu.pop();
    }
    if (!nam.empty()) cout<<"Con lai nam chua co cap.\n";
    if (!nu.empty()) cout<<"Con lai nu chua co cap.\n";
}
//Ứng dụng hàng đợi để cài thuật toán Radix Sort
void RadixSort(int arr[], int size) {
    LinkedQueueInt buckets[10];
    int maxVal = arr[0];
    for(int i = 1; i < size; i++) 
        if(arr[i] > maxVal) maxVal = arr[i];
    int maxDigits = 0;
    while(maxVal > 0) {
        maxDigits++;
        maxVal /= 10;
    }
    int placeValue = 1;
    for(int digit = 0; digit < maxDigits; digit++) {
        for(int i = 0; i < size; i++) {
            int digitVal = (arr[i] / placeValue) % 10;
            buckets[digitVal].Enqueue(arr[i]);
        }

        int index = 0;
        for(int i = 0; i < 10; i++) {
            while(!buckets[i].IsEmpty()) {
                arr[index++] = buckets[i].Dequeue();
            }
        }
        placeValue *= 10;
    }
}
int main() {
    int m;
    while(true) {
        cout<<"1. Xep lich mua\n";
        cout<<"2. Sap xep bang thuat toan Radix Sort\n";
        cout<<"3. Thoat\n";
        cin>>m;
        if(m == 1) XepLichMua();
        else if(m == 2) {
            int n; 
            cout<<"Nhap n: "; 
            cin>>n;
            int arr[n]; 
            for(int &x : arr) {
                cin >> x;
            }
            RadixSort(arr, n);
            for(int x : arr) {
                cout<<x<<" ";
            } 
        } else if(m == 3) break;
    }
    return 0;
}