#include <iostream>
#include <stack>
#include <string>
using namespace std;
//Ngăn xếp sử dụng mảng
struct StackInt {
    static const int MAX = 100;
    int arr[MAX];
    int top;
    StackInt() {top = -1;}
    void InitStack() {top = -1;}
    bool IsEmpty() {return top == -1;}
    bool IsFull() {return top == MAX - 1;}
    void PushStack(int x) {if(!IsFull()) arr[++top] = x;}
    int PopStack() {if(!IsEmpty()) return arr[top--]; return -1;}
    int PeepStack() {if(!IsEmpty()) return arr[top]; return -1;}
    void Clear() {top = -1;}
};
//Ngăn xếp sử dụng danh sách liên kết
struct LinkedStackInt {
    struct Node {
        int data;
        Node* next;
    };
    Node* top;
    LinkedStackInt() {top = nullptr;}
    void InitStack() {top = nullptr;}
    bool IsEmpty() {return top == nullptr;}
    void PushStack(int x) {top = new Node{x, top};}
    int PopStack() {
        if (IsEmpty()) return -1;
        int val = top->data;
        Node* temp = top;
        top = top->next;
        delete temp;
        return val;
    }
    int PeepStack() {return IsEmpty() ? -1 : top->data;}
    void Clear() {while(!IsEmpty()) PopStack();}
};
//Ứng dụng ngăn xếp để đảo số nguyên
int DaoSo(int num) {
    stack<int> s;
    while(num > 0) {
        s.push(num % 10);
        num = num / 10;
    }
    int Dao = 0;
    int place = 1;
    while(!s.empty()) {
        Dao = Dao + s.top() * place;
        s.pop();
        place = place * 10;
    }
    return Dao;
}
//Ứng dụng ngăn xếp để kiểm tra xâu đối xứng
bool LaDoiXung(const string& str) {
    stack<char> s;
    for(char ch : str) {
        s.push(ch);
    }
    string ThuTu;
    while(!s.empty()) {
        ThuTu = ThuTu + s.top();
        s.pop();
    }
    return ThuTu == str;
}
//Ứng dụng ngăn xếp để đổi từ thập phân sang nhị phân
string SangNhiPhan(int num) {
    stack<int> s;
    while(num > 0) {
        s.push(num % 2);
        num = num / 2;
    }
    string NhiPhan;
    while(!s.empty()) {
        NhiPhan = NhiPhan + to_string(s.top());
        s.pop();
    }
    return NhiPhan;
}
//Chuyển biểu thức trung tố sang hậu tố
int Pre(char op) {
    if(op == '+' || op == '-') {
        return 1;
    }
    if(op == '*' || op == '/') {
        return 2;
    }
    return 0;
}
string SangHauTo(const string& TrungTo) {
    stack<char> s;
    string HauTo;
    for(char ch : TrungTo) {
        if(isdigit(ch)) {
            HauTo = HauTo + ch;
        } else if(ch == '(') {
            s.push(ch);
        } else if(ch == ')') {
            while(!s.empty() && s.top() != '(') {
                HauTo = HauTo + s.top();
                s.pop();
            }
            s.pop();
        } else {
            while(!s.empty() && Pre(s.top()) >= Pre(ch)) {
                HauTo = HauTo + s.top();
                s.pop();
            }
            s.push(ch);
        }
    }
    while(!s.empty()) {
        HauTo = HauTo + s.top();
        s.pop();
    }
    return HauTo;
}
//Tính giá trị biểu thức hậu tố
int TinhGiaTri(const string& HauTo) {
    stack<int> s;
    for(char ch : HauTo) {
        if(isdigit(ch)) {
            s.push(ch - '0');
        } else {
            int b = s.top(); s.pop();
            int a = s.top(); s.pop();
            switch(ch) {
                case '+': s.push(a + b); break;
                case '-': s.push(a - b); break;
                case '*': s.push(a * b); break;
                case '/': s.push(a / b); break;
            }
        }
    }
    return s.top();
}
int main() {
    int num;
    cout<<"Nhap so can dao: ";
    cin>>num;
    cout<<"Dao so: "<<DaoSo(num)<<endl;
    string str;
    cout<<"Nhap xau can kiem tra doi xung: ";
    cin>>str;
    cout<<"Kiem tra xau doi xung: "<<(LaDoiXung(str) ? "co" : "khong")<<endl;
    int n;
    cout<<"Nhap so can chuyen sang nhi phan: ";
    cin>>n;
    cout<<"Doi tu so thap phan sang nhi phan: "<<SangNhiPhan(n)<<endl;
    string TrungTo;
    cout<<"Nhap bieu thuc trung to: ";
    cin>>TrungTo;
    string HauTo = SangHauTo(TrungTo);
    cout<<"Sang hau to: "<<HauTo<<endl;
    cout<<"Gia tri bieu thuc: "<<TinhGiaTri(HauTo)<<endl;
    return 0;
}
