#include <iostream>
#include <vector>
#include <set>
using namespace std;
int main() {
    int nx, ny, nz;
    // Nhập dãy x cho chương trình'
    cout<<"Nhap day x: "<<endl;
    cin >> nx;
    set<int> x;
    cout<<"Nhap cac phan tu cua day x: "<<endl;
    for (int i = 0; i < nx; ++i) {
        int num;
        cin >> num;
        x.insert(num);
    }
    // Nhập dãy y cho chương trình.
    cout<<"Nhap day y: "<<endl;
    cin >> ny;
    set<int> y;
    cout<<"Nhap cac phan tu cua day y: "<<endl;
    for (int i = 0; i < ny; ++i) {
        int num;
        cin >> num;
        y.insert(num);
    }
    // Nhập dãy z cho chương trình.
    cout<<"Nhap day z: "<<endl;
    cin >> nz;
    set<int> z;
    cout<<"Nhap cac phan tu cua day z: "<<endl;
    for (int i = 0; i < nz; ++i) {
        int num;
        cin >> num;
        z.insert(num);
    }
    // Tìm phần tử chung giữa 3 dãy nếu có.
    set<int> common;
    for (int num : x) {
        if (y.count(num) && z.count(num)) {
            common.insert(num);
        }
    }
    // Hiển thị kết quả.
    int commonSize = common.size();
    cout << commonSize << endl;
    if (!common.empty()) {
        for (int num : common) {
            cout << num << " ";
        }
        cout << endl;
    } 
    // Nếu cả 3 dãy không có phần tử chung.
    else {
        cout << "Khong co phan tu chung." << endl;
    }
    return 0;
}