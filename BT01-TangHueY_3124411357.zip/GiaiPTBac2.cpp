#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main() {
    int a, b, c;
    double delta, x1, x2;
    // Nhập các hệ số cho chương trình.
    cout<<"Nhap he so a: ";
    cin>>a;
    cout<<"Nhap he so b: ";
    cin>>b;
    cout<<"Nhap he so c: ";
    cin>>c;
     // Xác định liệu a có khác 0 hay không, nếu a khác 0 thì tính delta.
    if (a != 0) {
        delta = b*b-4*a*c;
        // Nếu delta > 0, xác định chương trình có 2 nghiệm phân biệt và tính cả 2 nghiệm.
        if (delta > 0) {
            x1 = (-b+sqrt(delta))/(2*a);
            x2 = (-b-sqrt(delta))/(2*a);
            // Xác định số lớn hơn giữa 2 nghiệm.
            if (x1 > x2) {
                swap(x1, x2);
            }
            cout<<"Phuong trinh co 2 nghiem "<<endl;
            cout<<fixed<<setprecision(2)<<x1<<" "<<x2<<endl;
        } 
        // Nếu delta = 0, xác định chương trình có 1 nghiệm và tính nghiệm kép của chương trình.
        else if (delta == 0) {
            x1 = -b/(2*a);
            cout<<"Phuong trinh co 1 nghiem "<<endl;
            cout<<fixed<<setprecision(2)<<x1<<endl;
        } 
        // Nếu delta < 0,xác định chương trình vô nghiệm.
        else {
            cout<<"Phuong trinh vo nghiem\n"<<endl;
        }
    } 
    // Nếu a = 0, xác định chương trình có vô số nghiệm.
    else {
        cout<<"Phuong trinh co vo so nghiem\n"<<endl;
    }
    return 0;
}