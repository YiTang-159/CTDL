#include <iostream>
#include <cstdio>
using namespace std;
#define FI "Data.inp"
void InputData(int &n) {
    FILE *fi = fopen(FI, "r");
    if (fi == NULL) {
        cout<<"Khong the doc file"<<endl;
        return;
    }
    fscanf(fi, "%d", &n);
    fclose(fi);
}
int main() {
    int n;
    InputData(n);
    cout<<"n = "<<n<<endl;
    return 0;
}