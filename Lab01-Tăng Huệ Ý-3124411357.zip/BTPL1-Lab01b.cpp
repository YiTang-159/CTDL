#include <iostream>
#include <cmath>
using namespace std;
void ptb2(double a, double b, double c, double *x1, double *x2) {
    double delta = b * b - 4 * a * c;
    if(delta > 0) {
        *x1 = (-b + sqrt(delta)) / (2 * a);
        *x2 = (-b - sqrt(delta)) / (2 * a);
    } else if(delta == 0) {
        *x1 = *x2 = -b / 2 * a;
    } else {
        *x1 = *x2 = 0;
    }
}
int main() {
    double a, b, c, x1, x2;
    cout<<"Nhap he so a, b, c: ";
    cin>>a>>b>>c;
    while (a == 0) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>a>>b>>c;
    }
    ptb2(a, b, c, &x1, &x2);
    if(b * b - 4 * a * c > 0) {
        cout<<"Phuong trinh co 2 nghiem x1 = "<<x1<<" x2 = "<<x2<<".";
    } else if(b * b - 4 * a * c == 0) {
        cout<<"Phuong trinh co 1 nghiem kep x = "<<x1<<".";
    } else {
        cout<<"Phuong trinh vo nghiem.";
    }
    return 0;
}