#include <iostream>
#include <cstring>
using namespace std;
#define MAX 100
struct Sach {
    char MaSach[11], TenSach[21];
    int Gia;
};
void Nhap1QuyenSach(Sach &s) {
    cout<<"Ma sach: ";
    cin.ignore();
    cin.getline(s.MaSach, 11);
    cout<<"Ten sach: ";
    cin.getline(s.TenSach, 21);
    cout<<"Gia: ";
    cin>>s.Gia;
}
void Xuat1QuyenSach(Sach s) {
    cout<<"Ma sach: "<<s.MaSach<<endl;
    cout<<"Ten sach: "<<s.TenSach<<endl;
    cout<<"Gia: "<<s.Gia<<endl;
}
void NhapMangSach(Sach a[], int &n) {
    cout<<"Nhap so luong sach: ";
    cin>>n;
    for(int i = 0; i < n; i++) {
        cout<<"Nhap quyen sach thu "<<i<<": ";
        Nhap1QuyenSach(a[i]);
    }
}
int TimSachTheoMa(Sach a[], int n, char ma[], Sach &kq) {
    int TimThay = 0;
    int i = 0;
    while(i < n && TimThay == 0) {
        if(strcmp(ma, a[i].MaSach) == 0) {
            kq = a[i];
            TimThay = 1;
        }
        i++;
    }
    return TimThay;
}
int main() {
    Sach a[MAX];
    int n;
    NhapMangSach(a, n);
    char ma[11];
    cout<<"Nhap ma sach muon tim: ";
    cin.ignore();
    cin.getline(ma, 11);
    Sach kq;
    int TimThay;
    TimThay = TimSachTheoMa(a, n, ma, kq);
    if(TimThay == 1) {
        cout<<"Quyen sach tim duoc la: "<<endl;
        Xuat1QuyenSach(kq);
    } else {
        cout<<"Khong tim thay quyen sach nao co ma da cho";
    }
    return 0;
}