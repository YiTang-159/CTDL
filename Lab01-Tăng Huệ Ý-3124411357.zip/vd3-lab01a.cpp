#include <iostream>
using namespace std;
int main() {
    int a[5] = {2, 4, 5, 8};
    int na = 3;
    int* p = NULL;
    p = a + 1;
    cout<<"p: Addr = "<<&p<<", Val = "<<*p<<", ValRef = "<<*(p)<<endl;
    p = p + 1;
    int x = p[-2];
    int* b = NULL;
    int nb = 0;
    nb = 3;
    b = new int[nb];
    *(b + 0) = 10;
    *(b + 1) = 20;
    b[2] = 30;
    if(b != NULL) {
        delete[] b;
    }
    return 0;
}