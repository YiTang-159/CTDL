#include <iostream>
#include <algorithm>
#include <string>
using namespace std;
#define MAX 1000
int main() {
    string s;
    cout<<"Moi ban nhap chuoi s: ";
    cin>>s;
    while(s.length() > MAX) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>s;
    }
    cout<<"Chuoi \""<<s<<"\" sau khi sap xep: ";
    sort(s.begin(),s.end());
    cout<<s<<endl;
    return 0;
}