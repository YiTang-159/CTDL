#include <iostream>
using namespace std;
bool ktxk(int a[], int n) {
    for(int i = 1; i < n; i++) {
        if((a[i] % 2 == 0 && a[i - 1] % 2 == 0) || (a[i] % 2 != 0 && a[i - 1] % 2 != 0)) {
            return false;
        }
    }
    return true;
}
bool kttc(int a[], int n) {
    for(int i = 0; i < n; i++) {
        if(a[i] % 2 != 0) {
            return false;
        }
    }
    return true;
}
int main() {
    int n;
    const int MAX_SIZE = 100;
    cout<<"Moi ban nhap so luong phan tu: ";
    cin>>n;
    while(n<= 0 || n > MAX_SIZE) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>n;
    }
    int a[n];
    for(int i = 0; i < n; i++) {
        cout<<"Phan tu "<<i<<": ";
        cin>>a[i];
    }
    if(ktxk(a, n)) {
        cout<<"+ Day co tinh chat chan le"<<endl;
    } else {
        cout<<"+ Day khong co tinh chat chan le"<<endl;
    }
    if(kttc(a, n)) {
        cout<<"+ Day co tinh chat toan chan"<<endl;
    } else {
        cout<<"+ Day khong co tinh chat toan chan"<<endl;
    }
    return 0;
}