#include <iostream>
#define MAX 100
using namespace std;
void NhapMang(int **a, int *n) {
    cout<<"Moi ban nhap so luong phan tu: ";
    cin>>*n;
    while(*n <= 0 || *n > MAX) {
        cout<<"Nhap sai! Nhap lai: ";
        cin>>*n;
    }
    *a = new int[*n];
    for (int i = 0; i < *n; i++) {
        cout<<"Phan tu "<<i<<": ";
        cin>>(*a)[i];
    }
}
void XuatMang(int *a, int n) {
    cout<<"Day so co "<<n<<" phan tu: ";
    for (int i = 0; i < n; i++) {
        cout<<a[i]<<" ";
    }
}
int DemChan(int *a, int n) {
    int dem = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] % 2 == 0) {
            dem++;
        }
    }
    return dem;
}
void TachChan(int *a, int n, int **b, int *m) {
    *m = DemChan(a, n);
    *b = new int[*m];
    int cs = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] % 2 == 0) {
            (*b)[cs++] = a[i];
        }
    }
}
int main() {
    int *b = nullptr, k = 0;
    int *aChan = nullptr, nChan = 0;
    NhapMang(&b, &k);
    TachChan(b, k, &aChan, &nChan);
    cout<<"+ Day chua cac so chan" << endl;
    XuatMang(aChan, nChan);
    if (b != nullptr) {
        delete[] b;
    }
    if (aChan != nullptr) {
        delete[] aChan;
    }
    return 0;
}