#include <iostream>
#include <vector>
using namespace std;
#define MAX 100
bool TinhDanDau(const vector <double>& a) {
    int n = a.size();
    if(n < 2) {
        return false;
    }
    for(int i = 0; i < n - 1; i++) {
        if((a[i] > 0 && a[i + 1] > 0) || (a[i] < 0 && a[i + 1] < 0)) {
            return false;
        }
    }
    return true;
}
bool TinhDonDieu(const vector <double>& a) {
    int n = a.size();
    if(n < 2) {
        return false;
    }
    bool tang = true, giam = true;
    for(int i = 0; i < n - 1; i++) {
        if(a[i] > a[i + 1]) {
            tang = false;
        }
        if(a[i] < a[i + 1]) {
            giam = false;
        }
    }
    return tang || giam;
}
bool TinhDoiXung(const vector <double>& a) {
    int n = a.size();
    if(n < 2) {
        return false;
    }
    for(int i = 0; i < n - 1; i++) {
        if(a[i] != a[n - i -1]) {
            return false;
        } else {
            return true;
        }
    }
}
int main() {
    int n;
    cout<<"Moi ban nhap so luong phan tu: ";
    cin>>n;
    while(n <= 0 || n > MAX) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>n;
    }
    vector <double> a(n);
    for(int i = 0; i < n; i++) {
        cout<<"Phan tu "<<i<<": ";
        cin>>a[i];
    }
    if(TinhDanDau(a)) {
        cout<<"+ Day co tinh chat dan dau"<<endl;
    } else {
        cout<<"+ Day khong co tinh chat dan dau"<<endl;
    }
    if(TinhDonDieu(a)) {
        cout<<"+ Day co tinh chat don dieu"<<endl;
    } else {
        cout<<"+ Day khong co tinh chat don dieu"<<endl;
    }
    if(TinhDoiXung(a)) {
        cout<<"+ Day co tinh chat doi xung"<<endl;
    } else {
        cout<<"+ Day khong co tinh chat doi xung"<<endl;
    }
    return 0;
}