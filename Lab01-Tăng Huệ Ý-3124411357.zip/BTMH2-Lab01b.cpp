#include <iostream>
#include <cmath>
using namespace std;
bool XacDinhSoPhanTu(int n) {
    if(n < 0) {
        return false;
    }
    int sqrt_n = sqrt(n);
    return (sqrt_n * sqrt_n == n);
}
int main() {
    int n;
    cout<<"Moi ban nhap so nguyen n: ";
    cin>>n;
    if(XacDinhSoPhanTu(n)) {
        cout<<"So "<<n<<" la so chinh phuong."<<endl;
    } else {
        cout<<"So "<<n<<" khong la so chinh phuong."<<endl;
    }
    return 0;
}