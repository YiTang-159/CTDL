#include <iostream>
#include <cstring>
using namespace std;
#define MAX 1000 
bool KiemTraDoiXung(const char *s) {
    int len = strlen(s);
    for (int i = 0; i < len / 2; i++) {
        if (s[i] != s[len - i - 1]) {
            return false;
        }
    }
    return true;
}
int main() {
    char s.Chuoi[MAX + 1] = {0}; 
    cout<<"Moi ban nhap chuoi s: ";
    cin.getline(s.Chuoi, MAX + 1);
    if (KiemTraDoiXung(s.Chuoi)) {
        cout<<"Chuoi \""<<s.Chuoi<<"\" la chuoi doi xung."<<endl;
    } else {
        cout<<"Chuoi \""<<s.Chuoi<<"\" khong la chuoi doi xung."<<endl;
    }
    return 0;
}