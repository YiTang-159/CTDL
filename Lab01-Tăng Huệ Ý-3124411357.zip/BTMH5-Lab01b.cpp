#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
#define MAX 100
bool SoNguyenTo(int n) {
    if(n < 2) {
        return false;
    }
    for(int i = 2; i <= sqrt(n); i++) {
        if(n % i == 0) {
            return false;
        }
    }
    return true;
}
int main() {
    int n;
    cout<<"Moi ban nhap so luong phan tu: ";
    cin>>n;
    while(n <= 0 || n > MAX) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>n;
    }
    vector <double> a(n);
    for(int i = 0; i < n; i++) {
        cout<<"Phan tu "<<i<<": ";
        cin>>a[i];
    }
    int count = 0;
    for(int i = 0; i < n; i++) {
        int num = static_cast<int>(a[i]);
        if(SoNguyenTo(num)) {
            count++;
        }
    }
    if(count > 0) {
        cout<<"+ Mang chua cac so nguyen to"<<endl;
    } else {
        cout<<"+ Mang khong chua cac so nguyen to"<<endl;
    }
    cout<<"Day so co "<<count<<" phan tu: ";
    for(int i = 0; i < n; i++) {
        int num = static_cast<int>(a[i]);
        if(SoNguyenTo(num)) {
            cout<<num<<" ";
        }
    }
    return 0;
}