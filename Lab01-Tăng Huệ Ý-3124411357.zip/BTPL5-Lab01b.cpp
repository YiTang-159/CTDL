#include <iostream>
#include <cmath>
using namespace std;
int main() {
    int n;
    const int MAX_SIZE = 100;
    cout<<"+ Day so a"<<endl;
    cout<<"Moi ban nhap so luong phan tu: ";
    cin>>n;
    while(n <= 0 || n > MAX_SIZE) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>n;
    }
    int* a = new int[n];
    for(int i = 0; i < n; i++) {
        cout<<"Phan tu "<<i<<": ";
        cin>> *(a + i);
    }
    int* b = new int[n];
    int* c = new int[n];
    int b_size = 0, c_size = 0;
    for(int i = 0; i < n; i++) {
        if(*(a + i) % 2 == 0) {
            *(b + b_size) = *(a + i);
            b_size++;
        } else {
            *(c + c_size) = *(a + i);
            c_size++;
        }
    }
    cout<<"+ Day so b chua so chan"<<endl;
    cout<<"Day so co "<<b_size<<" phan tu: ";
    for(int i = 0; i < b_size; i++) {
        cout<<*(b + i)<<" ";
    }
    cout<<endl;
     cout<<"+ Day so c chua so le"<<endl;
    cout<<"Day so co "<<c_size<<" phan tu: ";
    for(int i = 0; i < c_size; i++) {
        cout<<*(c + i)<<" ";
    return 0;
    }
}