#include <iostream>
using namespace std;
#define MAX 100 
bool LaNguyenAm(char c) {
    if(c =='a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
        return true;
    } else {
        return false;
    }
}
int main() {
    int n;
    cout<<"Moi ban nhap so luong phan tu: ";
    cin>>n;
    while(n <= 0 || n > MAX) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>n;
    }
    char a[n];
    for(int i = 0; i < n; i++) {
        cout<<"Moi ban nhap phan tu thu "<<i + 1<<" cho day : ";
        cin>>a[i];
    }
    char b[n];
    int j = 0;
    for(int i = 0; i < n; i++) {
        if(LaNguyenAm(a[i])) {
            b[j++] = a[i];
        }
    }
    cout<<"Day gom cac nguyen am la: ";
    for(int i = 0; i < j; i++) {
        cout<<b[i]<<" ";
    }
    return 0;
}