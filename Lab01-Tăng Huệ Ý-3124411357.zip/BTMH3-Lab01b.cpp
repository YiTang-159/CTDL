#include <iostream>
using namespace std;
#define MAX 100
void NhapMang(int **a, int *n) {
    cout<<"Moi ban nhap so luong phan tu: ";
    cout>>n;
    while((*n) <= 0 || (*n) > MAX) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>n;
    }
    (*a) = new int((*n));
    for(int i = 0; i < n; i++) {
        cout<<"Phan tu "<<i<<": ";
        cin>>(*a) + i;
    }
}
void XuatMang(int *a, int n) {
    cout<<"Day so co "<<n<<" phan tu: ";
    for(int i = 0; i < n; i++) {
        cout<<*(a + i);
    }
}
int DemChan(int *a, int n) {
    int dem = 0;
    for(int i = 0; i < n; i++) {
        if(*(a + i) % 2 == 0) dem++;
    }
    return dem;
}
void TachChan(int *a, int n, int **b, int *m) {
    (*m) = DemChan(a, n);
    (*b) = new int((*m));
    int cs = 0;
    for(int i = 0; i < n; i++) {
        if(*(a + i) % 2 == 0) {
            *((*b) + cs) = *(a + i);
            cs++
        }
    }
}
int main() {
    int *b = NULL, k = 0;
    int *aChan = NULL, nChan;
    NhapMang(&b. &k);
    TachChan(b, k, &aChan, &nChan);
    cout<<"+ Day chua cac so chan";
    XuatMang(aChan, nChan);
    return 0;
}