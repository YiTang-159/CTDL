#include <iostream>
#include <algorithm>
using namespace std;
int main() {
    int n, m;
    const int MAX_SIZE = 100;
    cout<<"+ Day so a"<<endl;
    cout<<"Moi ban nhap so luong phan tu: ";
    cin>>n;
    while(n <= 0 || n > MAX_SIZE) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>n;
    }
    float* a = new float[n];
    for(int i = 0; i < n; i++) {
        cout<<"Phan tu "<<i<<": ";
        cin>> *(a + i);
    }
    cout<<"+ Day so b"<<endl;
    cout<<"Moi ban nhap so luong phan tu: ";
    cin>>m;
    while(m <= 0 || m > MAX_SIZE) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>m;
    }
    float* b = new float[m];
    for(int i = 0; i < m; i++) {
        cout<<"Phan tu "<<i<<": ";
        cin>> *(b + i);
    }
    float* c = new float[n + m];
    for(int i = 0; i < n; i++) {
        *(c + i) = *(a + i);
    }
    for(int i = 0; i < m; i++) {
        *(c + n + i) = *(b + i);
    }
    sort(c, c + n + m);
    cout<<"Day so c"<<endl;
    cout<<"Day so co "<<n + m<<" phan tu: ";
    for(int i = 0; i < n + m; i++) {
        cout<<*(c + i)<<" ";
    }
    return 0;
}