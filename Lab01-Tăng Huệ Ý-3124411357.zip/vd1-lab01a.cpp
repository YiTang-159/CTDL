#include <iostream>
using namespace std;
int main() {
    int n;
    int *p = NULL;
    n = 20;
    p = &n;
    cout<<"n: Addr = "<<&n<<", Val = "<<n<<endl;
    cout<<"p: Addr = "<<&p<<", Val = "<<p<<", ValRef = "<<*p<<endl;
    int *pn = nullptr;
    pn = new int;
    *pn = 10;
    cout<<"sizeof(int): "<<sizeof(int)<<" byte(s)"<<endl;
    cout<<"pn: Addr = "<<&pn<<", Val = "<<pn<<", ValRef = "<<*pn<<endl;
    delete pn;
    return 0;
}