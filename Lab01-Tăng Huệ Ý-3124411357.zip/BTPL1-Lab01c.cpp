#include <iostream>
#include <string>
using namespace std;
#define MAX 100
struct NhanVien {
    char MaSo[11], Ho[11], Ten[51];
    int Phai, ThamNien;
};
struct PhongBan {
    NhanVien aNhanVien[MAX];
    int SoLuong;
};
void NhapPhongBan(PhongBan &pb) {
    cout<<"Nhap so luong nhan vien: ";
    cin>>pb.SoLuong;
    while(pb.SoLuong <= 0 || pb.SoLuong > MAX) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>pb.SoLuong;
    }
    for(int i = 0; i < pb.SoLuong; i++) {
        cout<<"Nhap thong tin nhan vien: "<<endl;
        cout<<"+ Ma so: ";
        cin.ignore();
        cin.getline(pb.aNhanVien[i].MaSo, 11);
        cout<<"+ Ho lot: ";
        cin.getline(pb.aNhanVien[i].Ho, 11);
        cout<<"+ Ten: ";
        cin.getline(pb.aNhanVien[i].Ten, 51);
        cout<<"+ Phai: ";
        cin>>pb.aNhanVien[i].Phai;
        while(pb.aNhanVien[i].Phai != 0 && pb.aNhanVien[i].Phai != 1) {
            cout<<"Ban da nhap sai, moi nhap lai: ";
            cin>>pb.aNhanVien[i].Phai;
        }
        cout<<"+ So nam lam viec: ";
        cin>>pb.aNhanVien[i].ThamNien;
        while(pb.aNhanVien[i].ThamNien < 0) {
            cout<<"Ban da nhap sai, moi nhap lai: ";
            cin>>pb.aNhanVien[i].ThamNien;
        }
        cout<<endl;
    }
}
void XuatPhongBan(const PhongBan pb) {
    cout<<"Phong ban co "<<pb.SoLuong<<" nhan vien: "<<endl;
    cout<<"STT\t Ma so\t Ho ten\t\t Phai\t So nam lam viec\n ";
    for(int i = 0; i < pb.SoLuong; i++) {
        cout<<i + 1<<"\t"
        <<pb.aNhanVien[i].MaSo<<"\t"
        <<pb.aNhanVien[i].Ho<<" "<<pb.aNhanVien[i].Ten<<"\t";
        if(pb.aNhanVien[i].Phai == 1) {
            cout<<"Nam";
        } else {
            cout<<"Nu";
        }
        cout<<"\t"<<pb.aNhanVien[i].ThamNien;
    }
}
void DemSiSo(const PhongBan pb, int &sonam, int &sonu) {
    sonam = sonu = 0;
    for(int i = 0; i < pb.SoLuong; i++) {
        if(pb.aNhanVien[i].Phai == 1) {
            sonam++;
        } else {
            sonu++;
        }
    }
}
void SapXepTangTheoThamNien(PhongBan pb) {
    for(int i = 0; i < pb.SoLuong - 1; i++) {
        for(int j = i + 1; j < pb.SoLuong; j++) {
            if(pb.aNhanVien[i].ThamNien < pb.aNhanVien[j].ThamNien) {
                NhanVien tmp = pb.aNhanVien[i];
                pb.aNhanVien[i] = pb.aNhanVien[j];
                pb.aNhanVien[j] = tmp;
            }
        }
    }
}
int main() {
    PhongBan pb;
    int sonam, sonu;
    NhapPhongBan(pb);
    XuatPhongBan(pb);
    DemSiSo(pb,sonam, sonu);
    cout<<"Phong ban co "<<pb.SoLuong<<" nhan vien, trong do co "<<sonam<<" nam va "<<sonu<<" nu"<<endl;
    cout<<"Danh sach nhan vien theo tham nien: ";
    SapXepTangTheoThamNien(pb);
    XuatPhongBan(pb);
    return 0;
}