#include <iostream>
#include <string>
using namespace std;
#define MAX 20
struct LoaiHoa {
    string Ten;
    string DVT;
    int SoLuong, DonGia;
};
struct DanhSachLoaiHoa {
    LoaiHoa DanhSachLoaiHoa[MAX];
    int SoLuongHoa;
};
void NhapDanhSach(DanhSachLoaiHoa &ds) {
    cout<<"Nhap so loai hoa: ";
    cin>>ds.SoLuongHoa;
    while(ds.SoLuongHoa <= 0 || ds.SoLuongHoa > MAX) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>ds.SoLuongHoa;
    }
    for(int i = 0; i < ds.SoLuongHoa; i++) {
        cout<<"Nhap thong tin loai hoa: "<<endl;
        cout<<"+ Ten loai hoa: ";
        cin.ignore();
        getline(ds.DanhSachLoaiHoa[i].Ten);
        cout<<"+ So luong loai hoa: ";
        cin>>ds.DanhSachLoaiHoa[i].SoLuong;
        cout<<"+ Don Vi Tinh: ";
        cin.ignore();
        getline(cin, ds.DanhSachLoaiHoa[i].DVT);
        cout<<"+ Don Gia: ";
        cin>>ds.DanhSachLoaiHoa[i].DonGia;
        while(ds.DanhSachLoaiHoa[i].DonGia <= 0) {
            cout<<"Ban da nhap sai, moi nhap lai: ";
            cin>>ds.DanhSachLoaiHoa[i].DonGia;
        }
    }
}
void XuatDanhSach(const DanhSachLoaiHoa ds) {
    cout<<"Danh sach co "<<ds.SoLuongHoa<<" loai hoa: "<<endl;
    cout<<"STT\t Ten Loai Hoa\t So Luong\t Don Vi Tinh\t Don Gia\n ";
    for(int i = 0; i < ds.SoLuongHoa; i++) {
        cout<<i + 1<<"\t"
        <<ds.DanhSachLoaiHoa[i].Ten<<"\t"
        <<ds.DanhSachLoaiHoa[i].SoLuong<<"\t"
        <<ds.DanhSachLoaiHoa[i].DVT<<"\t"
        <<ds.DanhSachLoaiHoa[i].DonGia<<"VND\n";
    }
}
int TimLoaiHoa(DanhSachLoaiHoa ds, const string &tenloai) {
    for(int i = 0; i < ds.SoLuongHoa; i++) {
        if(ds.DanhSachLoaiHoa[i].Ten == tenloai) {
            return i;
        }
        return -1;
    }
}
void XuLyBanHoa(DanhSachLoaiHoa &ds, const string &tenloai, int soluong) {
    int ViTri = TimLoaiHoa(ds, tenloai); {
        if(ViTri == -1) {
            cout<<"Trong kho khong co loai hoa nay"<<endl;
        } else {
            if(soluong <= ds.DanhSachLoaiHoa[ViTri].SoLuong) {
                int TongTien = ds.DanhSachLoaiHoa[ViTri].DonGia * soluong;
                cout<<"Trong kho co loai hoa nay"<<endl;
                cout<<"Tong tien: "<<endl;
            } else {
                cout<<"Trong kho khong du so luong loai hoa yeu cau";
            }
        }
    }
}
int main() {
    DanhSachLoaiHoa ds;
    NhapDanhSach(ds);
    XuatDanhSach(ds);
    string tenloai;
    int soluong;
    cout<<"Nhap ten loai hoa khach yeu cau: ";
    cin.ignore();
    getline(cin, tenloai);
    cout<<"Nhap so luong hoa khach yeu cau: ";
    cin>>soluong;
    XuLyBanHoa(ds, tenloai, soluong);
    return 0;
}