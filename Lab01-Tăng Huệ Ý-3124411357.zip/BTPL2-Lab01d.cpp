#include <iostream>
#include <string>
using namespace std;
#define MAX 1000
int main() {
    string s;
    int k;
    cout<<"Moi ban nhap chuoi s: ";
    cin>>s;
    while(s.length() > MAX) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>s;
    }
    cout<<"Moi ban nhap vi tri can xoa: ";
    cin>>k;
    while(k < 0 || k > s.length() - 1) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>k;
    }
    cout<<"Chuoi \""<<s<<"\" sau khi xoa ky tu tai vi tri "<<k<<": ";
    s.erase(k, 1);
    cout<<s;
    return 0;
}