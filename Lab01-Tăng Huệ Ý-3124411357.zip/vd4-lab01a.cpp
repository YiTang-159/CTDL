#include <iostream>
using namespace std;
#define MAX 100;
void NhapMang(int *&a, int &n) {
    cout<<"Moi ban nhap so luong phan tu: ";
    cin>>n;
    a = new int[n];
    for (int i = 0; i < n; i++) {
        cout<<"Phan tu "<<i<<": ";
        cin>>a[i];
    }
}
void NhapMang(int **a, int *n) {
    cout<<"Moi ban nhap so luong phan tu: ";
    cin>>*n;
    *a = new int[*n];
    for (int i = 0; i < *n; i++) {
        cout<<"Phan tu "<<i<<": ";
        cin>>(*a)[i];
    }
}
void XuatMang(int *a, int n) {
    cout<<"Day so co "<<n<<" phan tu: ";
    for (int i = 0; i < n; i++) {
        cout<<a[i]<<" ";
    }
}
void DoiChan(int *a, int n) {
    for (int i = 0; i < n; i++) {
        if (a[i] % 2 == 0) {
            a[i] = 0;
        }
    }
}
int main() {
    int *b = nullptr, k = 0;
    NhapMang(b, k);
    XuatMang(b, k);
    DoiChan(b, k);
    cout<<"* Doi gia tri chan thanh cac so 0: "<<endl;
    XuatMang(b, k);
    if (b != nullptr) {
        delete[] b;
    }
    return 0;
}