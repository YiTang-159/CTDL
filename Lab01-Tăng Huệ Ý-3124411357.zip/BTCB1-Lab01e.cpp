#include <iostream>
#include <fstream>
using namespace std;
#define MAX 1000
#define FI "DaySoNguyen.inp"
void InputData(int a[], int &n) {
    cout<<"Nhap so phan tu cua mang: ";
    cin>>n;
    for(int i = 0; i < n; i++) {
        cout<<"Nhap so nguyen thu "<<i + 1<<" cua mang: ";
        cin>>a[i];
    }
}
void OutputData(int a[], int n) {
    FILE *fo;
    fo = fopen(FI, "wt");
    if(fo == NULL) {
        cout<<"Khong the tao file";
        return;
    }
    fprintf(fo, "%d\n", n);
    for(int i = 0; i < n; i++) {
        fprintf(fo, "%d", a[i]);
    }
    fclose(fo);
}
int main() {
    int a[MAX];
    int n;
    InputData(a, n);
    OutputData(a, n);
    return 0;
}