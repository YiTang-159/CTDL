#include <iostream>
using namespace std;
#define MAX 100
#define FO "Data.out"
void NhapMang1C(int a[], int &n) {
    cout<<"Nhap so luong phan tu: ";
    cin>>n;
    for (int i = 0; i < n; i++) {
        cout<<"Nhap phan tu thu "<<i + 1<<": ";
        cin>>a[i];
    }
}
void OutputData(int a[], int n) {
    FILE *fo = fopen(FO, "w");
    if (fo == NULL) {
        cout<<"Khong the tao file"<<endl;
        return;
    }
    fprintf(fo, "%d\n", n);
    for (int i = 0; i < n; i++) {
        fprintf(fo, "%d\n", a[i]);
    }
    fclose(fo);
}
int main() {
    int a[MAX];
    int n;
    NhapMang1C(a, n);
    OutputData(a, n);
    return 0;
}