#include <iostream>
#include <string>
using namespace std;
#define MAX 1000
int main() {
    string s;
    int k;
    char c;
    cout<<"Moi ban nhap chuoi s: ";
    cin>>s;
    while(s.length() > MAX) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>s;
    }
    cout<<"Moi ban nhap vi tri can chen: ";
    cin>>k;
    while(k < 0 || k > s.length() - 1) {
        cout<<"Ban da nhap sai, moi nhap lai: ";
        cin>>k;
    }
    cout<<"Moi ban nhap ky tu chen: ";
    cin>>c;
    cout<<"Chuoi \""<<s<<"\" sau khi them ky tu \""<<c<<"\" tai vi tri "<<k<<": ";
    s.insert(k, 1, c);
    cout<<s;
    return 0;
}