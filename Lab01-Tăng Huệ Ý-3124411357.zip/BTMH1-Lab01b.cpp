#include <iostream>
using namespace std;
void Hoanvi(int *x, int *y) { 
    int tmp = *x;
    *x = *y;
    *y = tmp;
}
int main() {
    int a, b;
    cout<<"Moi ba nhap so a: ";
    cin>>a;
    cout<<"Moi ba nhap so b: ";
    cin>>b;
    cout<<"Truoc khi hoan vi, a = "<<a<<" va b = "<<b<<"."endl;
    Hoanvi(&a, &b);
    cout<<"Sau khi hoan vi, a = "<<a<<" va b = "<<b<<"."endl;
    return 0;
}