#include <iostream>
#include <cstring>
using namespace std;
#define MAX 1000
bool CoKyTuSo(const char *s) {
    int len = strlen(s);
    for (int i = 0; i < len; i++) {
        if (s[i] >= '0' && s[i] <= '9') {
            return true;
        }
    }
    return false;
}
int main() {
    char s.Chuoi[MAX + 1] = {0};
    bool kq;
    cout<<"Moi ban nhap chuoi s: ";
    cin.getline(sChuoi, MAX + 1);
    kq = CoKyTuSo(s.Chuoi);
    if (kq) {
        cout<<"Chuoi \""<<s.Chuoi<<"\" co chua ky tu so."<<endl;
    } else {
        cout<<"Chuoi \""<<s.Chuoi<<"\" khong co chua ky tu so."<<endl;
    }
    return 0;
}