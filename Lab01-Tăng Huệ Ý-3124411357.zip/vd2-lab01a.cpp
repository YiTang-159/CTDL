#include <iostream>
using namespace std;
void HoanVi(int a, int b) {
    int tmp = a;
    a = b;
    b = tmp;
}
void HoanVi(int &a, int &b) {
    int tmp = a;
    a = b;
    b = tmp;
}
void HoanVi(int *a, int *b) {
    int tmp = *a;
    *a = *b;
    *b = tmp;
}
int main() {
    int x = 5, y = 10;
    cout<<"Tham tri: x = "<<x<<", y = "<<y<<endl;
    HoanVi(x, y);
    cout<<"Tham tri: x = "<<x<<", y = "<<y<<endl;
    cout<<"Tham bien: x = "<<x<<", y = "<<y<<endl;
    HoanVi(x, y);
    cout<<"Tham bien: x = "<<x<<", y = "<<y<<endl;
    cout<<"Tham chieu: x = "<<x<<", y = "<<y<<endl;
    HoanVi(&x, &y);
    cout<<"Tham chieu: x = "<<x<<", y = "<<y<<endl;
    int x = 5, *y = &x;
    cout<<"x: Addr = "<<&x<<", Val = "<<x<<endl;
    cout<<"y: Addr = "<<&y<<", Val = "<<y<<endl;
}